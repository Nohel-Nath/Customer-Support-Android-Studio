package com.example.newdesign

data class OpenBoAccount(val boText: String)
