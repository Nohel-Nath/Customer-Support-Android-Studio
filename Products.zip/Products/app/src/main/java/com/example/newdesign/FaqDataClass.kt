package com.example.newdesign

data class FaqDataClass(val questions: String, val answers: String)
