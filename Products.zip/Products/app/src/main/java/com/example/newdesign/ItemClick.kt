package com.example.newdesign

interface OnItemClickListener {
    fun onItemClick(item: OpenBoAccount)
}