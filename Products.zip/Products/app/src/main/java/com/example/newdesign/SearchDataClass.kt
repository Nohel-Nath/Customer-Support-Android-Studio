package com.example.newdesign

data class SearchDataClass(val item: String)
