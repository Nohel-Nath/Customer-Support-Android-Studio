package com.example.newdesign

enum class NidUpload {
    FRONT_PART,
    BACK_PART
}