package com.example.newdesign

data class Album(val images: List<String>, val albumName: String, val albumCount: Int)
