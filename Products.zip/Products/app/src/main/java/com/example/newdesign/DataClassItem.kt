package com.example.newdesign

data class DataClassItem(
    val postId: Int,
    val id: Int,
    val name: String,
    val email: String,
    val body: String
)