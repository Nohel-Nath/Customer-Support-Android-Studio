package com.example.newdesign

class DataClass : ArrayList<DataClassItem>()