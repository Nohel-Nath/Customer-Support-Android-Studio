package com.example.imageupload

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import com.example.imageupload.databinding.ActivityCaptureBinding
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import android.app.Activity
import android.net.Uri
import android.view.View
import androidx.core.net.toUri
import com.bumptech.glide.Glide
import java.io.File

class CaptureActivity : AppCompatActivity() {
    private lateinit var binding: ActivityCaptureBinding
    private var imageCapture: ImageCapture? = null
    private lateinit var cameraExecutor: ExecutorService
    private lateinit var outputDirectory: File
    private var listener:ImageSelectionInterFace?=null

    fun setImageSelectionListener(listener: ImageSelectionInterFace) {
        this.listener = listener
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCaptureBinding.inflate(layoutInflater)
        setContentView(binding.root)
        startCamera()
        binding.btn.setOnClickListener {
            takePhoto()
        }
        outputDirectory = getOutputDirectory()
        cameraExecutor = Executors.newSingleThreadExecutor()
    }


    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
    private fun takePhoto() {
        val imageCapture = imageCapture ?: return
        val photoFile = File(
            outputDirectory,
            SimpleDateFormat(FILENAME_FORMAT, Locale.US
            ).format(System.currentTimeMillis()) + ".jpg")
        val outputOptions = ImageCapture.OutputFileOptions.Builder(photoFile).build()
        imageCapture.takePicture(
            outputOptions, ContextCompat.getMainExecutor(this), object : ImageCapture.OnImageSavedCallback {
                override fun onError(exc: ImageCaptureException) {
                    Log.e(TAG, "Photo capture failed: ${exc.message}", exc)
                }
                override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                    val savedUri = output.savedUri ?: photoFile.toUri()

                    binding.insidePreviewView.post {
                        binding.insideImageView.visibility=View.VISIBLE
                        binding.insidePreviewView.visibility=View.INVISIBLE
                        Glide.with(this@CaptureActivity)
                            .load(savedUri)
                            .into(binding.insideImageView)
                        binding.btnCross.visibility = View.VISIBLE
                        binding.btnClick.visibility = View.VISIBLE
                        binding.btn.visibility = View.INVISIBLE
                    }
                    binding.btnClick.setOnClickListener {
//                        // Other code
                        val resultIntent = Intent()
                        resultIntent.putExtra("imageUri", savedUri.toString())
                        setResult(Activity.RESULT_OK, resultIntent)
                        finish()
//                        //listener?.onImageSelected(savedUri)
                        Log.d(TAG, "Photo capture succeeded: $savedUri")
                        showToast("Photo saved successfully!")

//                        if (savedUri != null) {
//                            // Pass the image URI to the MainActivity via the interface
//                            listener?.onImageSelected(savedUri)
//                        }
                    }

                    binding.btnCross.setOnClickListener {
                        binding.insideImageView.setImageURI(null)
                        binding.insideImageView.visibility=View.INVISIBLE
                        binding.insidePreviewView.visibility=View.VISIBLE
                        binding.btnCross.visibility = View.GONE
                        binding.btnClick.visibility = View.GONE
                        binding.btn.visibility = View.VISIBLE
                    }
                }
            })
    }
    private fun getOutputDirectory(): File {
        val mediaDir = externalMediaDirs.firstOrNull()?.let {
            File(it, resources.getString(R.string.app_name)).apply { mkdirs() }
        }
        return if (mediaDir != null && mediaDir.exists())
            mediaDir else filesDir
    }
    private fun startCamera() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)
        cameraProviderFuture.addListener({
            val cameraProvider: ProcessCameraProvider = cameraProviderFuture.get()
            val preview = Preview.Builder()
                .build()
                .also {
                    it.setSurfaceProvider(binding.insidePreviewView.surfaceProvider)
                }
            imageCapture = ImageCapture.Builder()
                .build()
            val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA
            try {
                cameraProvider.unbindAll()

                cameraProvider.bindToLifecycle(
                    this, cameraSelector, preview, imageCapture
                )
            } catch (exc: Exception) {
                Log.e(TAG, "Use case binding failed", exc)
            }
        }, ContextCompat.getMainExecutor(this))
    }
    override fun onDestroy() {
        super.onDestroy()
        cameraExecutor.shutdown()
    }
    companion object {
        private const val TAG = "CameraXApp"
        private const val FILENAME_FORMAT = "yyyy-MM-dd-HH-mm-ss-SSS"
    }
}
