package com.example.imageupload

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.AnimationUtils
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

import com.example.imageupload.databinding.BottomlayoutBinding
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialogFragment

class FullscreenModalBottomSheetDialog: BottomSheetDialogFragment() {
    private lateinit var binding : BottomlayoutBinding
    private val cameraPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
        if (isGranted) {
            startActivity(Intent(requireContext(),CaptureActivity::class.java))
        } else {
            if (!shouldShowRequestPermissionRationale(Manifest.permission.CAMERA)) {
                explainFeatureUnavailable()
            }
        }
    }
    private fun explainFeatureUnavailable() {
        AlertDialog.Builder(requireContext())
            .setTitle("Feature Unavailable")
            .setMessage("The Image selection feature is currently unavailable because the storage permission has been denied.")
            .setPositiveButton("OK") { dialog, _ ->
                dialog.dismiss()
            }.setNegativeButton("Open Settings") { _, _ ->
                openAppSettings()
            }.show()
    }
    private fun openAppSettings() {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
        val uri = Uri.fromParts("package", requireContext().packageName, null)
        intent.data = uri
        startActivity(intent)
    }
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = BottomlayoutBinding.inflate(inflater, container, false)
        val toolbar = binding.toolbar
        toolbar.setNavigationOnClickListener {
            dismiss()
        }
        return binding.root
    }
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val bottomSheet: FrameLayout = dialog?.findViewById(com.google.android.material.R.id.design_bottom_sheet)!!
        bottomSheet.layoutParams.height = ViewGroup.LayoutParams.MATCH_PARENT
        val behavior = BottomSheetBehavior.from(bottomSheet)
        behavior.apply {
            peekHeight = resources.displayMetrics.heightPixels // Pop-up height
            state = BottomSheetBehavior.STATE_EXPANDED// Expanded state
            addBottomSheetCallback(object : BottomSheetBehavior.BottomSheetCallback() {
                override fun onStateChanged(bottomSheet: View, newState: Int) {
                }
                override fun onSlide(bottomSheet: View, slideOffset: Float) {}
            })
        }
        binding.btnCamera.setOnClickListener {
            if (isCameraPermissionGranted()) {
                startActivity(Intent(requireContext(),CaptureActivity::class.java))
            } else {
                requestCameraPermission()
            }
        }
        val slideUpAnimation = AnimationUtils.loadAnimation(requireContext(), R.anim.slide_in_bottom)
        bottomSheet.startAnimation(slideUpAnimation)
    }

    private fun requestCameraPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            startActivity(Intent(requireContext(),CaptureActivity::class.java))
        } else {
            when {
                ContextCompat.checkSelfPermission(
                    requireContext(),
                    Manifest.permission.CAMERA
                ) == PackageManager.PERMISSION_GRANTED -> {
                    startActivity(Intent(requireContext(),CaptureActivity::class.java))
                }
                ActivityCompat.shouldShowRequestPermissionRationale(
                    requireActivity(),
                    Manifest.permission.CAMERA
                ) -> {
                    showPermissionRationaleDialog()
                }
                else -> {
                    cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                }
            }
        }
    }
    private fun showPermissionRationaleDialog() {
        AlertDialog.Builder(requireContext())
            .setTitle("Storage Permission")
            .setMessage("Storage permission is needed in order to show images and videos")
            .setNegativeButton("Cancel") { dialog, _ ->
                Log.d("showPermissionRationaleDialog1:", "showPermissionRationaleDialog1 is working.")
                dialog.dismiss()
            }
            .setPositiveButton("OK") { _, _ ->
                cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
            }
            .show()
    }
    private fun isCameraPermissionGranted(): Boolean {
        return ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
    }
}


