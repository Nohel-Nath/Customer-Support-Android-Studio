package com.example.imageupload

import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.bumptech.glide.Glide
import com.example.imageupload.databinding.ActivityMainBinding


class MainActivity : AppCompatActivity(), ImageSelectionInterFace {
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.hide()
        setUpModalButtons()
//
//        var captureClass=CaptureActivity()
//        captureClass.setImageSelectionListener(this)

        }

    private fun setUpModalButtons() {
        binding.apply {
            bottomSheetArrow.setOnClickListener {
                val fullscreenModal = FullscreenModalBottomSheetDialog()
                supportFragmentManager.let {
                    fullscreenModal.show(
                        it,
                        "FullscreenModalBottomSheetDialog"
                    )
                }
            }
        }
    }

    override fun onImageSelected(imageUri: Uri) {
        Glide.with(this).load(imageUri).into(binding.imageViewForCamera)
    }
}

/*
imagePickerLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
    if (result.resultCode == AppCompatActivity.RESULT_OK) {
        val intent = result.data
        val uri = intent?.data
        // Handle the result
        binding.imageView.setImageURI(uri)
        binding.cancelButton1.visibility = View.VISIBLE
        binding.tvImageContainer.visibility = View.GONE
    }
}



binding.butImage.setOnClickListener {
    openGallery()
}
binding.cancelButton1.setOnClickListener {
    // Reset the ImageView and hide the Cancel button
    binding.tvImageContainer.visibility = View.VISIBLE
    binding.imageView.setImageURI(null)
    binding.cancelButton1.visibility = View.GONE
}*/

/*
// Get the BottomSheetBehavior from the ConstraintLayout within the dialog
            val bottomSheetLayout = sheetView.findViewById<ConstraintLayout>(R.id.bottom_sheet_layout)
            val layoutParams = bottomSheetLayout.layoutParams as CoordinatorLayout.LayoutParams
            val behavior = layoutParams.behavior
            if (behavior is BottomSheetBehavior) {
                // Set the state of the bottom sheet to expanded
                behavior.state = BottomSheetBehavior.STATE_EXPANDED
            }
 */

/*

//            sheetView.findViewById<Button>(R.id.btn_gallery).setOnClickListener {
//                // Display toast message when Gallery button is clicked
//                showToast("Gallery button clicked")
//            }

 */