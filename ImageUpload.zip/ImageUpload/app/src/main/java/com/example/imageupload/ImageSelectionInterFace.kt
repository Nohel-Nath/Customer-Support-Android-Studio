package com.example.imageupload

import android.net.Uri

interface ImageSelectionInterFace {
    fun onImageSelected(imageUri: Uri)
}